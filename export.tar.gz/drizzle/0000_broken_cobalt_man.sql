CREATE TABLE `guilds` (
	`id` text(20) PRIMARY KEY NOT NULL,
	`services` text DEFAULT '{}' NOT NULL
);
